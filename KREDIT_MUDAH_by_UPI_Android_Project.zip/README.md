# KREDIT MUDAH by UPI — Android APK Project

Project Android Studio yang membungkus aplikasi web KREDIT MUDAH by UPI dalam WebView.

## Cara build APK
1. Install Android Studio terbaru.
2. Open folder project ini.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
- Aplikasi kalkulator berjalan offline.
- Tidak ada database/server pada versi ini.
- Hasil simulasi adalah estimasi dan bukan keputusan kredit.
